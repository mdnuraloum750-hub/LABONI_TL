package com.tl.assistant

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "TL AI Assistant"
            textSize = 28f
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            text = "স্বাগতম! এটি প্রাথমিক সংস্করণ। পূর্ণ AI এখনো সংযুক্ত করা হয়নি।"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "বাংলায় কথা বলো"
            setOnClickListener { voiceInput() }
        })
        layout.addView(Button(this).apply {
            text = "ফোনের Settings খোলো"
            setOnClickListener { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "একটি ফাইল বেছে নাও"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(i, 22)
            }
        })
        setContentView(layout)
    }

    private fun voiceInput() {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় বলুন")
            }
            startActivityForResult(i, 11)
        } catch (_: Exception) {
            Toast.makeText(this, "ভয়েস ইনপুট পাওয়া যাচ্ছে না।", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated API used for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == 11) {
            val result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            status.text = result?.let { "তুমি বলেছ: $it\nপূর্ণ AI সংযোগ এখনো নেই।" } ?: "কথা বোঝা যায়নি।"
        } else if (requestCode == 22) {
            status.text = "তুমি একটি ফাইল নির্বাচন করেছ।"
        }
    }
}

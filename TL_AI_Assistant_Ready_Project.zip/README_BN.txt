TL AI Assistant — Ready Project

IMPORTANT:
- This ZIP is an Android source project, NOT an installable APK.
- The app is a starter prototype: Bengali speech recognition launch, Android Settings shortcut, and a user-selected file picker.
- It does not yet contain a connected AI model/API and cannot control the whole phone.
- The GitHub Actions workflow is included at .github/workflows/build.yml. Upload the CONTENTS of this folder to the repository root (not the ZIP itself), then open GitHub -> Actions -> Build TL AI Assistant APK -> Run workflow. After success, download the artifact named TL-AI-Assistant-debug-APK.
- Never share GitHub passwords or OTPs.
